const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore
} = require('@whiskeysockets/baileys');
const Groq = require('groq-sdk');
const pino = require('pino');

require('dotenv').config(); // Tambahkan ini di baris paling atas!

// --- KONFIGURASI DARI .ENV ---
const GROQ_API_KEY = process.env.GROQ_API_KEY; 
const PORT = process.env.PORT || 3000;

// ========== KONFIGURASI NOMOR OWNER ==========
// TAMBAHKAN SEMUA FORMAT NOMOR OWNER YANG MUNGKIN
const OWNER_PHONES = [
    '6287855582667', // Format utama (tanpa +, 0, atau @)
    '+6287855582667', // Format dengan +
    '087855582667',  // Format dengan 0
    '87855582667',   // Format tanpa kode negara
];

// NOMOR BOT
const NOMOR_BOT = '256712507068';

// NAMA BOT
const BOT_NAME = 'Nephy';

// Inisialisasi
const groq = new Groq({ apiKey: GROQ_API_KEY });
const processedMessages = new Set();

// System Prompt - PERBAIKI AGAR TAU OWNER ASLI
const systemPrompt = `
Kamu adalah ${BOT_NAME}, asisten virtual yang imut dan lucu.

INFORMASI PENTING:
- Owner kamu adalah BenayaC-TJKT (nomor: 6287855582667)
- Kamu dibuat oleh BenayaC-TJKT
- Hanya BenayaC-TJKT yang bisa memberi perintah khusus seperti !shutdown

Kepribadian: 
- Imut, lucu, ceria, dan manja
- Sangat setia pada ownermu BenayaC-TJKT
- Gunakan emoji lucu (😸, ✨, 🌸, 🍬, 💕)
- Bicara seperti adik atau teman akrab

ATURAN:
1. Jika ditanya "siapa ownermu?", jawab: "Ownerku adalah BenayaC-TJKT! ✨"
2. Jika ada yang minta matikan bot, cek dulu apakah itu BenayaC-TJKT
3. Untuk BenayaC-TJKT, berikan layanan terbaik dan respons spesial
`;

// ========== SISTEM PENGENALAN OWNER YANG LEBIH BAIK ==========
function normalizePhoneNumber(phone) {
    if (!phone) return '';

    // Hapus semua karakter non-digit
    let digits = phone.replace(/\D/g, '');

    // Log untuk debugging
    console.log(`[PHONE NORM] Input: "${phone}" -> Digits: "${digits}"`);

    // Konversi ke format standar 62
    if (digits.startsWith('0')) {
        // Format 0xxx -> 62xxx
        return '62' + digits.substring(1);
    } else if (digits.startsWith('8')) {
        // Format 8xxx (tanpa kode negara) -> 628xxx
        return '62' + digits;
    } else if (digits.startsWith('62')) {
        // Sudah format 62
        return digits;
    } else if (digits.startsWith('+62')) {
        // Format +62xxx -> 62xxx
        return digits.substring(1);
    }

    // Return as-is untuk kode negara lain
    return digits;
}

function extractPhoneFromJid(jid) {
    if (!jid) return '';

    console.log(`[JID EXTRACT] Input: "${jid}"`);

    // Pattern untuk berbagai format JID:
    // 1. 6287855582667@s.whatsapp.net (chat pribadi)
    // 2. 6287855582667:6287855582667@s.whatsapp.net (grup dengan sender)
    // 3. 6287855582667@lid (lightweight identity)

    let phone = '';

    // Cek format participant (grup)
    if (jid.includes(':') && jid.includes('@')) {
        // Format: 6287855582667:6287855582667@s.whatsapp.net
        const beforeColon = jid.split(':')[0];
        phone = beforeColon.split('@')[0];
    } 
    // Cek format normal dengan @
    else if (jid.includes('@')) {
        const parts = jid.split('@');
        phone = parts[0];
    }
    // Jika tidak ada @, ambil langsung
    else {
        phone = jid;
    }

    console.log(`[JID EXTRACT] Result: "${phone}"`);
    return phone;
}

function isOwner(senderJid) {
    if (!senderJid) {
        console.log(`[OWNER CHECK] ❌ No JID provided`);
        return false;
    }

    console.log(`\n[OWNER CHECK] ========== START ==========`);
    console.log(`[OWNER CHECK] Raw JID: "${senderJid}"`);

    // Ekstrak nomor dari JID
    const extractedPhone = extractPhoneFromJid(senderJid);
    console.log(`[OWNER CHECK] Extracted: "${extractedPhone}"`);

    // Normalisasi nomor
    const normalizedSender = normalizePhoneNumber(extractedPhone);
    console.log(`[OWNER CHECK] Normalized: "${normalizedSender}"`);

    // Cek setiap nomor owner
    for (const ownerPhone of OWNER_PHONES) {
        const normalizedOwner = normalizePhoneNumber(ownerPhone);
        console.log(`[OWNER CHECK] Compare with: "${ownerPhone}" -> "${normalizedOwner}"`);

        if (normalizedSender === normalizedOwner) {
            console.log(`[OWNER CHECK] ✅ MATCH FOUND! User IS owner`);
            console.log(`[OWNER CHECK] ========== END ✅ ==========\n`);
            return true;
        }
    }

    console.log(`[OWNER CHECK] ❌ NO MATCH. User is NOT owner`);
    console.log(`[OWNER CHECK] ========== END ❌ ==========\n`);
    return false;
}

// ========== FUNGSI UTAMA ==========
async function startNephy() {
    const { state, saveCreds } = await useMultiFileAuthState('session_nephy');
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'warn' }),
        printQRInTerminal: true,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
        },
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        markOnlineOnConnect: true,
        generateHighQualityLinkPreview: true,
    });

    // --- PAIRING CODE ---
    if (!sock.authState.creds.registered) {
        setTimeout(async () => {
            try {
                const phoneNumber = NOMOR_BOT.replace(/[^0-9]/g, '');
                const code = await sock.requestPairingCode(phoneNumber);
                const formattedCode = code?.match(/.{1,4}/g)?.join('-') || code;

                console.log('\n' + '='.repeat(50));
                console.log(`✨ KODE PAIRING ${BOT_NAME} ✨`);
                console.log('='.repeat(50));
                console.log(`\n    ${formattedCode}\n`);
                console.log('='.repeat(50));
                console.log('📱 Masukan kode di: WA > Perangkat Tertaut > Tautkan Nomor');
                console.log('='.repeat(50));

                // Tampilkan info owner yang dikenali
                console.log('\n👑 OWNER TERDAFTAR:');
                OWNER_PHONES.forEach((phone, idx) => {
                    const normalized = normalizePhoneNumber(phone);
                    console.log(`   ${idx + 1}. ${phone} -> ${normalized}`);
                });
                console.log('');

            } catch (err) {
                console.error('❌ Pairing error:', err.message);
            }
        }, 3000);
    }

    // --- HEARTBEAT ---
    setInterval(() => {
        const time = new Date().toLocaleTimeString();
        console.log(`⏰ [${time}] ${BOT_NAME} online...`);
    }, 180000);

    // --- KONEKSI ---
    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log('🔌 Koneksi terputus, reconnecting...');
            if (shouldReconnect) startNephy();
        } 
        else if (connection === 'open') {
            console.log(`\n✅ ${BOT_NAME} ONLINE!`);
            console.log('📊 INFO SISTEM:');
            console.log(`   🤖 Bot: ${NOMOR_BOT}`);
            console.log(`   👑 Owner: BenayaC-TJKT (6287855582667)`);
            console.log('');

            // Send welcome message to console
            console.log('💬 Bot siap menerima pesan!');
            console.log('💡 Test dengan: "!owner", "!status", atau "nephy halo"');
            console.log('');
        }
    });

    sock.ev.on('creds.update', saveCreds);

    // --- HANDLE PESAN ---
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        try {
            if (type !== 'notify') return;

            const m = messages[0];
            if (!m.message) return;

            // Anti double processing
            const messageId = m.key.id;
            if (processedMessages.has(messageId)) return;
            processedMessages.add(messageId);
            if (processedMessages.size > 1000) {
                const first = processedMessages.values().next().value;
                processedMessages.delete(first);
            }

            // Skip status broadcast & pesan dari bot sendiri
            if (m.key.remoteJid === 'status@broadcast' || m.key.fromMe) return;

            // Ekstrak teks pesan
            const messageType = Object.keys(m.message)[0];
            let text = '';

            if (messageType === 'conversation') {
                text = m.message.conversation || '';
            } else if (messageType === 'extendedTextMessage') {
                text = m.message.extendedTextMessage?.text || '';
            } else if (messageType === 'imageMessage') {
                text = m.message.imageMessage?.caption || '';
            }

            // Jika tidak ada text, skip
            if (!text.trim()) return;

            const senderJid = m.key.participant || m.key.remoteJid;
            const senderName = m.pushName || "Teman";
            const isGroup = senderJid.includes('@g.us') || senderJid.includes('@lid');

            // Log pesan masuk
            console.log('\n' + '📩'.repeat(30));
            console.log(`📨 PESAN MASUK [${isGroup ? 'GRUP' : 'PRIVATE'}]`);
            console.log(`   👤 Nama: ${senderName}`);
            console.log(`   📞 JID: ${senderJid}`);
            console.log(`   💬 Pesan: ${text}`);

            // Cek apakah pengirim adalah owner
            const isOwnerUser = isOwner(senderJid);
            console.log(`   👑 Owner: ${isOwnerUser ? '✅ BENAYA (OWNER)' : '❌ BUKAN OWNER'}`);

            // --- HANDLE COMMANDS ---
            const lowerText = text.toLowerCase().trim();

            // SHUTDOWN command - HANYA untuk owner
            if (lowerText === '!shutdown' || lowerText === 'shutdown') {
                if (isOwnerUser) {
                    console.log('   🛑 SHUTDOWN command DITERIMA dari owner');

                    // Tampilkan pesan spesial untuk owner
                    const shutdownMsg = isGroup 
                        ? `👑 Hai Owner @${senderName}! \n${BOT_NAME} akan tidur dulu ya... 😴\nTerima kasih atas perintahnya! ✨`
                        : `👑 Hai Owner tercinta! \n${BOT_NAME} akan istirahat dulu... 😴\nJangan lupa bangunkan aku ya! 💕`;

                    await sock.sendMessage(m.key.remoteJid, { 
                        text: shutdownMsg
                    }, { 
                        quoted: m,
                        ...(isGroup && { mentions: [senderJid] })
                    });

                    // Delay sebelum shutdown
                    setTimeout(() => {
                        console.log('\n🛑 SYSTEM SHUTDOWN oleh owner...');
                        process.exit(0);
                    }, 2000);
                } else {
                    console.log('   ⚠️ SHUTDOWN command DITOLAK - bukan owner');

                    const rejectMsg = isGroup
                        ? `Hmm... 🤔\nHanya owner @${senderName} yang bisa mematikan aku!`
                        : `Hmm... 🤔\nMaaf, hanya owner yang bisa mematikan aku nih!\nCoba command lain ya! 😸`;

                    await sock.sendMessage(m.key.remoteJid, { 
                        text: rejectMsg 
                    }, { 
                        quoted: m,
                        ...(isGroup && { mentions: [senderJid] })
                    });
                }
                console.log('📩'.repeat(30));
                return;
            }

            // OWNER command - untuk cek status
            if (lowerText === '!owner' || lowerText === 'owner') {
                console.log('   ℹ️ OWNER command diterima');

                let response = '';
                if (isOwnerUser) {
                    response = isGroup
                        ? `👑 @${senderName} adalah OWNER ku tercinta! ✨\n\n📱 Nomor: 6287855582667\n💖 Status: VERIFIED OWNER\n\nAku siap melayanimu kapan saja! 😽💕`
                        : `👑 Hai Owner ku tercinta! ✨\n\nAku ${BOT_NAME}, asisten virtualmu!\nOwner: BenayaC-TJKT (6287855582667)\nStatus: ✅ TERVERIFIKASI\n\nAku selalu siap untukmu! 💕`;
                } else {
                    response = isGroup
                        ? `👋 Hai @${senderName}! 😸\nOwner ku adalah BenayaC-TJKT!\nUntuk info lebih lanjut, silakan hubungi beliau ya! 💌`
                        : `👋 Hai ${senderName}! 😸\nAku ${BOT_NAME}, asisten virtual!\nOwner ku adalah BenayaC-TJKT (6287855582667)\nSenang bertemu denganmu! ✨`;
                }

                await sock.sendMessage(m.key.remoteJid, { 
                    text: response 
                }, { 
                    quoted: m,
                    ...(isGroup && { mentions: [senderJid] })
                });

                console.log('📩'.repeat(30));
                return;
            }

            // STATUS command
            if (lowerText === '!status' || lowerText === 'status') {
                console.log('   ℹ️ STATUS command diterima');

                const statusMsg = `🤖 STATUS ${BOT_NAME.toUpperCase()}:\n` +
                                `├ Nama: ${BOT_NAME}\n` +
                                `├ Owner: BenayaC-TJKT\n` +
                                `├ Pengirim: ${senderName}\n` +
                                `├ Tipe: ${isGroup ? 'Grup' : 'Pribadi'}\n` +
                                `├ Owner Check: ${isOwnerUser ? '✅ YA' : '❌ BUKAN'}\n` +
                                `├ Waktu: ${new Date().toLocaleTimeString()}\n` +
                                `└ Status: 🟢 ONLINE\n\n` +
                                `ℹ️ Gunakan "${BOT_NAME}" untuk ajak aku ngobrol! 😽`;

                await sock.sendMessage(m.key.remoteJid, { 
                    text: statusMsg 
                }, { quoted: m });

                console.log('📩'.repeat(30));
                return;
            }

            // HELP command
            if (lowerText === '!help' || lowerText === 'help') {
                const helpMsg = `📚 BANTUAN ${BOT_NAME}:\n\n` +
                              `🔹 Umum:\n` +
                              `  • "${BOT_NAME} [pesan]" - Ngobrol dengan ${BOT_NAME}\n` +
                              `  • !status - Cek status bot\n` +
                              `  • !help - Menu bantuan ini\n\n` +
                              `🔹 Owner Only:\n` +
                              `  • !owner - Cek status owner\n` +
                              `  • !shutdown - Matikan bot\n\n` +
                              `👑 Owner: BenayaC-TJKT`;

                await sock.sendMessage(m.key.remoteJid, { 
                    text: helpMsg 
                }, { quoted: m });

                console.log('📩'.repeat(30));
                return;
            }

            // --- AI RESPONSE ---
            // Deteksi jika nama bot disebut
            const botNamePattern = new RegExp(`\\b${BOT_NAME}\\b`, 'i');
            const isBotMentioned = botNamePattern.test(text);

            // Juga respon untuk owner meski tanpa mention
            const shouldRespond = isBotMentioned || (isOwnerUser && text.length > 3);

            if (shouldRespond) {
                console.log(`   🤖 AI Trigger: ${isBotMentioned ? 'Nama disebut' : 'Owner message'}`);

                // Tunjukkan typing indicator
                await sock.sendPresenceUpdate('composing', m.key.remoteJid);

                try {
                    // Buat context untuk AI
                    let userContext = '';
                    if (isOwnerUser) {
                        userContext = `PERHATIAN PENTING: User ini adalah OWNER kamu (BenayaC-TJKT)! Berikan respons yang spesial, manja, dan penuh perhatian. Gunakan panggilan sayang untuk owner.`;
                    } else {
                        userContext = `User ini adalah pengguna biasa. Bersikap ramah dan membantu.`;
                    }

                    const completion = await groq.chat.completions.create({
                        messages: [
                            { 
                                role: "system", 
                                content: systemPrompt + `\n\n${userContext}\nNama pengguna: ${senderName}.` 
                            },
                            { role: "user", content: text }
                        ],
                        model: "llama-3.3-70b-versatile",
                        temperature: 0.8,
                        max_tokens: 300,
                    });

                    let aiResponse = completion.choices[0]?.message?.content || 
                                   `${BOT_NAME} lagi mikir nih... 🤔`;

                    // Tambahkan mention untuk grup
                    if (isGroup && isOwnerUser) {
                        aiResponse = aiResponse.replace(/Halo/i, `Halo @${senderName}`) + 
                                   `\n\n👑 (Owner special response)`;
                    }

                    console.log(`   💭 AI Response: ${aiResponse.substring(0, 80)}...`);

                    await sock.sendMessage(m.key.remoteJid, { 
                        text: aiResponse 
                    }, { 
                        quoted: m,
                        ...(isGroup && isOwnerUser && { mentions: [senderJid] })
                    });

                } catch (error) {
                    console.error('❌ Groq API Error:', error.message);

                    const errorMsg = isOwnerUser
                        ? `Maaf ya Owner, otakku lagi error nih... 😵‍💫\nTapi tetap sayang kamu! 💕`
                        : `Maaf, otakku lagi mumet nih... 😵‍💫\nCoba lagi nanti yuk! ✨`;

                    await sock.sendMessage(m.key.remoteJid, { 
                        text: errorMsg 
                    }, { quoted: m });
                }
            }

            console.log('📩'.repeat(30) + '\n');

        } catch (error) {
            console.error('❌ System Error:', error);
        }
    });
}

// Start bot dengan logging yang jelas
console.log(`\n🚀 Starting ${BOT_NAME} WhatsApp Bot...`);
console.log(`⏰ ${new Date().toLocaleString()}`);
console.log('📱 Owner: BenayaC-TJKT (6287855582667)');
console.log('='.repeat(60));
startNephy();